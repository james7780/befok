
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <machine\endian.h>


#ifndef uchar
  typedef unsigned char  uchar;
  typedef unsigned short ushort;
  typedef unsigned long  ulong;
#endif

